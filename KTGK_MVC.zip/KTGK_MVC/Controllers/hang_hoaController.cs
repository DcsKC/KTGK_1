﻿using KTGK_1.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;
//1

namespace KTGK_1.Controllers
{
    public class HangHoaController : Controller
    {
        private readonly HttpClient _httpClient;

        public HangHoaController(IHttpClientFactory httpClientFactory)
        {
            _httpClient = httpClientFactory.CreateClient("HangHoaAPI");
        }


        public async Task<IActionResult> Index()
        {
            string apiUrl = "http://localhost:5081/api/hang_hoa";
            var response = await _httpClient.GetAsync(apiUrl);

            if (!response.IsSuccessStatusCode)
            {
                return View("Error"); 
            }

            var jsonString = await response.Content.ReadAsStringAsync();
            var hangHoas = JsonConvert.DeserializeObject<List<hang_hoa>>(jsonString);

            return View("Index", hangHoas); 
        }
        [HttpGet]
        public async Task<IActionResult> Edit(string id)
        {
            string apiUrl = $"http://localhost:5081/api/hang_hoa/{id}";
            var response = await _httpClient.GetAsync(apiUrl);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound(); // Trả về lỗi 404 nếu không tìm thấy
            }

            var jsonString = await response.Content.ReadAsStringAsync();
            var hangHoa = JsonConvert.DeserializeObject<hang_hoa>(jsonString);

            return View("Edit", hangHoa);
        }
        [HttpPost]
        public async Task<IActionResult> Create(hang_hoa model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            string apiUrl = "http://localhost:5081/api/hang_hoa"; // Thay URL API đúng của bạn
            var jsonContent = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync(apiUrl, jsonContent);

            if (!response.IsSuccessStatusCode)
            {
                ModelState.AddModelError("", "Lỗi khi thêm hàng hóa!");
                return View(model);
            }

            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }



    }
}
