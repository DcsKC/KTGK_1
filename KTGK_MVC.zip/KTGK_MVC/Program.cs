﻿var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddHttpClient("HangHoaAPI", client =>
{
    client.BaseAddress = new Uri("http://localhost:5081/api/");
});

var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();

app.UseAuthorization();

// Routing mặc định cho MVC
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=hang_hoaMVC}/{action=Index}/{id?}");

app.Run();
